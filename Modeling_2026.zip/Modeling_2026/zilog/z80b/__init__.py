"""Model for Zilog Z80B."""
from .z80b_model import *
