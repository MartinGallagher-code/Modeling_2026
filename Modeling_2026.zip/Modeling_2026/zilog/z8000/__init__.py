"""Model for Zilog Z8000."""
from .z8000_model import *
