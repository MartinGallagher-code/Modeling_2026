"""Model for Zilog Z80A."""
from .z80a_model import *
