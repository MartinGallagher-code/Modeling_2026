"""Model for Zilog Z80."""
from .z80_model import *
