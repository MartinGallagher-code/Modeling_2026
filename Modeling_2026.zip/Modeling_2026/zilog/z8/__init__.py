"""Model for Zilog Z8."""
from .z8_model import *
