"""Model for Zilog Z80000."""
from .z80000_model import *
