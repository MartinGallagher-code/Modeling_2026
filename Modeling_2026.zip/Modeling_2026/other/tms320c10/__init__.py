"""Model for TI TMS320C10."""
from .tms320c10_model import *
