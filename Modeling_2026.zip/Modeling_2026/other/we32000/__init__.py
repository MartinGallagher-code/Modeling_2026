"""Model for AT&T WE 32000."""
from .we32000_model import *
