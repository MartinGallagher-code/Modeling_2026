"""Model for AMD Am2901."""
from .am2901_model import *
