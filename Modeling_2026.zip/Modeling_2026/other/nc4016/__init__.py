"""Model for Novix NC4016."""
from .nc4016_model import *
