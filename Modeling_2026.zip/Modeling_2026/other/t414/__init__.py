"""Model for Inmos T414."""
from .t414_model import *
