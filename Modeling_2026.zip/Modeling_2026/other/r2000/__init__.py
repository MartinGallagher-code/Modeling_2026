"""Model for MIPS R2000."""
from .r2000_model import *
