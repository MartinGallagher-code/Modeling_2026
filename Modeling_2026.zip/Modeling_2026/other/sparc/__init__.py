"""Model for Sun SPARC."""
from .sparc_model import *
