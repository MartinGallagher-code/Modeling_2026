"""Model for Signetics 2650."""
from .signetics2650_model import *
