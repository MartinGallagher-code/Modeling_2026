"""Model for TI TMS9900."""
from .tms9900_model import *
