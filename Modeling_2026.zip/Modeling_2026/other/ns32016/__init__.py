"""Model for National NS32016."""
from .ns32016_model import *
