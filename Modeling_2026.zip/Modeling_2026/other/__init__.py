"""OTHER processor family models."""
