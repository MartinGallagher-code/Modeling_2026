"""Model for TI TMS9995."""
from .tms9995_model import *
