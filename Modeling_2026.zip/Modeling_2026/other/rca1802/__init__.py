"""Model for RCA 1802."""
from .rca1802_model import *
