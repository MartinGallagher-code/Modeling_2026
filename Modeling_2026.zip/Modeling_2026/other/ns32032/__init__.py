"""Model for National NS32032."""
from .ns32032_model import *
