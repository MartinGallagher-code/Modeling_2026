"""Model for Acorn ARM1."""
from .arm1_model import *
