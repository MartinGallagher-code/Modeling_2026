"""Model for Harris RTX2000."""
from .rtx2000_model import *
