"""Model for National SC/MP."""
from .scmp_model import *
