"""Model for Fairchild F8."""
from .f8_model import *
