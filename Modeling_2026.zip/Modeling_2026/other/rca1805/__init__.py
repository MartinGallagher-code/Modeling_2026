"""Model for RCA 1805."""
from .rca1805_model import *
