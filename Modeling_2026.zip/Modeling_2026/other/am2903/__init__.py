"""Model for AMD Am2903."""
from .am2903_model import *
