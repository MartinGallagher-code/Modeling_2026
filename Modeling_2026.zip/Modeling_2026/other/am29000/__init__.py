"""Model for AMD Am29000."""
from .am29000_model import *
