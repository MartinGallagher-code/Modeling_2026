"""Model for Intel 80386."""
from .i80386_model import *
