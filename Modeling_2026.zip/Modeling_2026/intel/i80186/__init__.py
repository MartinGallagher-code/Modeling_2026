"""Model for Intel 80186."""
from .i80186_model import *
