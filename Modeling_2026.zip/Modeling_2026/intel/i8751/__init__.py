"""Model for Intel 8751."""
from .i8751_model import *
