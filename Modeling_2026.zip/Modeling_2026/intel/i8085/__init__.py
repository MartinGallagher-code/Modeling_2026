"""Model for Intel 8085."""
from .i8085_model import *
