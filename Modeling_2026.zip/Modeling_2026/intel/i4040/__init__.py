"""Model for Intel 4040."""
from .i4040_model import *
