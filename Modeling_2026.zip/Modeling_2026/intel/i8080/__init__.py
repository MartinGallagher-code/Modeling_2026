"""Model for Intel 8080."""
from .i8080_model import *
