"""Model for Intel 8008."""
from .i8008_model import *
