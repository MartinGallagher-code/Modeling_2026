"""Model for Intel 8086."""
from .i8086_model import *
