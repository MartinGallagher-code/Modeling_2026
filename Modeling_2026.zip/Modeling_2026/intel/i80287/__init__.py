"""Model for Intel 80287."""
from .i80287_model import *
