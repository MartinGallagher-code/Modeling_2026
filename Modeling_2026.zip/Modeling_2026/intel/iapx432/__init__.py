"""Model for Intel iAPX 432."""
from .iapx432_model import *
