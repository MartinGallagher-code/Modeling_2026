"""Model for Intel 8748."""
from .i8748_model import *
