"""Model for Intel 8088."""
from .i8088_model import *
