"""Model for Intel 80387."""
from .i80387_model import *
