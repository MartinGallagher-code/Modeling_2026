"""Model for Intel 8048."""
from .i8048_model import *
