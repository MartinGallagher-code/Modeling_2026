#!/usr/bin/env python3
"""
Intel 80188 Performance Model

Grey-box queueing model for the Intel 80188 microprocessor (1982).

Specifications:
- Clock: 8.0 MHz
- Bus Width: 8-bit
- Transistors: 55,000

Source: Intel 80186/80188 Users Manual
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from common.queueing import QueueingModel
from common.validation import create_standard_suite


# Processor configuration
CONFIG = {
    'name': 'Intel 80188',
    'year': 1982,
    'clock_mhz': 8.0,
    'bus_width': 8,
    'transistors': 55000
}

# Timing categories (5-15 categories capturing major instruction classes)
TIMING_CATEGORIES = {
    'mov_reg_reg': {
        'cycles': 2,
        'weight': 0.2,
        'description': 'MOV r,r',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'mov_reg_mem': {
        'cycles': 12,
        'weight': 0.15,
        'description': 'MOV r,m',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'alu_register': {
        'cycles': 3,
        'weight': 0.22,
        'description': 'ALU r,r',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'alu_memory': {
        'cycles': 16,
        'weight': 0.1,
        'description': 'ALU r,m',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'immediate': {
        'cycles': 3,
        'weight': 0.12,
        'description': 'Immediate ops',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'branch_taken': {
        'cycles': 13,
        'weight': 0.08,
        'description': 'Jcc taken',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'branch_not_taken': {
        'cycles': 4,
        'weight': 0.05,
        'description': 'Jcc not taken',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'call_return': {
        'cycles': 18,
        'weight': 0.05,
        'description': 'CALL/RET',
        'source': 'Intel 80186/80188 Users Manual'
    },
    'multiply': {
        'cycles': 40,
        'weight': 0.03,
        'description': 'MUL/IMUL',
        'source': 'Intel 80186/80188 Users Manual'
    },
}

# Validation targets from documentation
VALIDATION_TARGETS = {
    'ips_min': 700000,
    'ips_max': 1200000,
    'cpi_min': 7,
    'cpi_max': 12,
    'expected_bottlenecks': ['prefetch', 'bus_width'],
    'source': 'Intel 80186/80188 Users Manual'
}

# Create the queueing model
MODEL = QueueingModel(
    clock_mhz=CONFIG['clock_mhz'],
    timing_categories=TIMING_CATEGORIES,
    bus_width=CONFIG['bus_width']
)


def analyze(workload='typical'):
    """Analyze processor performance with given workload."""
    return MODEL.analyze(workload)


def validate():
    """Run validation suite."""
    result = analyze('typical')
    suite = create_standard_suite(
        CONFIG['name'],
        (VALIDATION_TARGETS['ips_min'], VALIDATION_TARGETS['ips_max']),
        (VALIDATION_TARGETS['cpi_min'], VALIDATION_TARGETS['cpi_max']),
        VALIDATION_TARGETS['expected_bottlenecks'],
        TIMING_CATEGORIES,
        [VALIDATION_TARGETS['source']],
        result.ips,
        result.cpi,
        result.bottleneck
    )
    return suite


def main():
    """Main entry point."""
    print(f"{CONFIG['name']} Performance Model")
    print("=" * 50)
    print(f"Clock: {CONFIG['clock_mhz']} MHz")
    print(f"Bus: {CONFIG['bus_width']}-bit")
    print(f"Transistors: {CONFIG['transistors']:,}")
    print()
    
    # Analyze with typical workload
    result = analyze('typical')
    print(f"IPS: {result.ips:,.0f}")
    print(f"CPI: {result.cpi:.2f}")
    print(f"Bottleneck: {result.bottleneck}")
    print()
    
    # Run validation
    suite = validate()
    results, all_passed = suite.run()
    print(suite.summary())


if __name__ == '__main__':
    main()
