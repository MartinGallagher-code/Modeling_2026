"""Model for Intel 80188."""
from .i80188_model import *
