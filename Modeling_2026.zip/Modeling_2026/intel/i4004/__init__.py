"""Model for Intel 4004."""
from .i4004_model import *
