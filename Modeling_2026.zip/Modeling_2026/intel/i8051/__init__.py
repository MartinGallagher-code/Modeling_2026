"""Model for Intel 8051."""
from .i8051_model import *
