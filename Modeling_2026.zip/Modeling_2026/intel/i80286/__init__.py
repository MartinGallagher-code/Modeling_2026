"""Model for Intel 80286."""
from .i80286_model import *
