"""Model for MOS 6510."""
from .mos6510_model import *
