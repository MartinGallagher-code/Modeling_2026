"""Model for MOS 6502."""
from .mos6502_model import *
