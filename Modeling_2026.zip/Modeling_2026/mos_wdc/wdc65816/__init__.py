"""Model for WDC 65816."""
from .wdc65816_model import *
