"""Model for WDC 65C02."""
from .wdc65c02_model import *
