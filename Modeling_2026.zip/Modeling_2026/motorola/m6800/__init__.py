"""Model for Motorola 6800."""
from .m6800_model import *
