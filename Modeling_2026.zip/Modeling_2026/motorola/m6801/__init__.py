"""Model for Motorola 6801."""
from .m6801_model import *
