"""Model for Motorola 68HC11."""
from .m68hc11_model import *
