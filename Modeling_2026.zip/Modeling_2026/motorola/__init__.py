"""MOTOROLA processor family models."""
