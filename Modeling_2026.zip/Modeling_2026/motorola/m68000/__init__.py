"""Model for Motorola 68000."""
from .m68000_model import *
