"""Model for Motorola 6802."""
from .m6802_model import *
