"""Model for Motorola 6809."""
from .m6809_model import *
