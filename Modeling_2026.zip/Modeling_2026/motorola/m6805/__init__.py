"""Model for Motorola 6805."""
from .m6805_model import *
