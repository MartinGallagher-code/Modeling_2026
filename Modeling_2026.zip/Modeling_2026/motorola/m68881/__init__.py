"""Model for Motorola 68881."""
from .m68881_model import *
