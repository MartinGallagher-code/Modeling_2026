"""Model for Motorola 68008."""
from .m68008_model import *
