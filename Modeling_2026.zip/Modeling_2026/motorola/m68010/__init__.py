"""Model for Motorola 68010."""
from .m68010_model import *
