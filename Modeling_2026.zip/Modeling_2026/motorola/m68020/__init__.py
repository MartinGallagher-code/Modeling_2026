"""Model for Motorola 68020."""
from .m68020_model import *
