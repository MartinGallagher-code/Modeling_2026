"""Model for Motorola 68882."""
from .m68882_model import *
